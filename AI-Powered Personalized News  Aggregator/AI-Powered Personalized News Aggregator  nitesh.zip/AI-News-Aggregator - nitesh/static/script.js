let sentimentChart;
let favorites = JSON.parse(localStorage.getItem("favorites")) || [];
let currentPage = 1;
let lastQuery = "technology";
let isLoading = false;
let hasMore = true;

const darkModeToggle = document.getElementById("darkModeToggle");
darkModeToggle.addEventListener("change", () =>
  document.body.classList.toggle("dark", darkModeToggle.checked)
);

const toggleFavoritesBtn = document.getElementById("toggleFavorites");
const favoritesContainer = document.getElementById("favoritesContainer");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");

// ---------------- Core helpers ----------------
function showLoading(show) {
  const loading = document.getElementById("loading");
  const container = document.getElementById("newsContainer");
  if (show) {
    loading.classList.remove("d-none");
    if (currentPage === 1) container.innerHTML = '<div class="skeleton"></div>'.repeat(6);
  } else {
    loading.classList.add("d-none");
  }
}

function showAlert(msg) {
  const alertBox = document.getElementById("alertBox");
  alertBox.textContent = msg;
  alertBox.classList.remove("d-none");
  setTimeout(() => alertBox.classList.add("d-none"), 4000);
}

function getCategoryIcon(category) {
  switch ((category || "").toLowerCase()) {
    case "technology": return "💻";
    case "sports": return "⚽";
    case "entertainment": return "🎬";
    case "business": return "💼";
    default: return "📰";
  }
}

// ---------------- Fetch News ----------------
async function fetchNews(query = "technology", page = 1) {
  if (isLoading || (!hasMore && page > 1)) return;
  isLoading = true;

  const lang = document.getElementById("language").value;
  query = (query || "technology").trim();
  lastQuery = query;
  currentPage = page;

  showLoading(true);

  try {
    const url = `/get_news?query=${encodeURIComponent(query)}&language=${encodeURIComponent(lang)}&page=${page}&page_size=6`;
    const res = await fetch(url);
    const data = await res.json();
    if (data.error) {
      showAlert(`⚠ ${data.message}`);
      hasMore = false;
    } else {
      hasMore = !!data.has_more;
      renderNews(data.items, page === 1);
    }
  } catch {
    showAlert("⚠ Failed to fetch news!");
  } finally {
    isLoading = false;
    showLoading(false);
    updatePaginationButtons();
  }
}

// ---------------- Render News ----------------
function renderNews(newsList, replace = false) {
  const container = document.getElementById("newsContainer");
  if (replace) container.innerHTML = "";

  if (!newsList || !newsList.length) {
    if (replace) {
      container.innerHTML = "<p>No news found.</p>";
      updateChart(0, 0, 0);
    }
    return;
  }

  let pos = 0, neu = 0, neg = 0;

  newsList.forEach(news => {
    const sentiment = (news.sentiment || "neutral").toLowerCase();
    if (sentiment === "positive") pos++;
    else if (sentiment === "negative") neg++;
    else neu++;

    const card = document.createElement("div");
    card.className = "col-md-4";
    card.innerHTML = `
      <div class="card h-100 shadow-sm news-card">
       <img src="${news.image || 'https://via.placeholder.com/400x200?text=No+Image'}"
           class="card-img-top zoomable" alt="News Image"
           onerror="this.src='https://via.placeholder.com/400x200?text=No+Image'">
        <div class="card-body d-flex flex-column">
          <span class="category-badge ${(news.category || 'default').toLowerCase()}">
            ${getCategoryIcon(news.category)} ${news.category || "General"}
          </span>
          <p style="font-size:0.8rem;color:#666;">🔍 Search: ${lastQuery}</p>
          <h5 class="card-title">${news.title}</h5>
          <p class="card-text">${news.summary || news.description || ""}</p>
          <p class="text-muted" style="font-size:0.85rem;">🕒 ${news.publishedAt ? new Date(news.publishedAt).toLocaleString() : ""}</p>
          <p><span class="badge bg-${sentiment === "positive" ? "success" : sentiment === "negative" ? "danger" : "secondary"}">${news.sentiment || "neutral"}</span></p>
          <div class="d-flex gap-1 mt-auto">
            <a href="${news.url}" target="_blank" class="btn btn-sm btn-primary flex-grow-1">📖 Read More</a>
            <button class="btn btn-sm btn-outline-info flex-grow-1 speak-btn">🔊 Listen</button>
            <button class="btn btn-sm btn-outline-warning flex-grow-1 fav-btn">⭐ Favorite</button>
            <button class="btn btn-sm btn-outline-success flex-grow-1 share-btn" data-url="${news.url}">📤 Share</button>
          </div>
          </div>
        </div>
      </div>
    `;

    card.querySelector(".speak-btn").addEventListener("click", () => speak(news.summary || news.description || news.title));
    card.querySelector(".fav-btn").addEventListener("click", () => addFavorite(news));
    container.appendChild(card);
  });

  if (replace) updateChart(pos, neu, neg);
}

// ---------------- Chart ----------------
function updateChart(pos, neu, neg) {
  const ctx = document.getElementById("sentimentChart").getContext("2d");
  if (sentimentChart) sentimentChart.destroy();
  sentimentChart = new Chart(ctx, {
    type: "pie",
    data: {
      labels: ["Positive 😀", "Neutral 😐", "Negative 😞"],
      datasets: [{ data: [pos, neu, neg], backgroundColor: ["#28a745", "#6c757d", "#dc3545"] }]
    }
  });
}

// ---------------- Favorites ----------------
function addFavorite(news) {
  if (favorites.some(f => f.url === news.url)) return;
  favorites.push(news);
  localStorage.setItem("favorites", JSON.stringify(favorites));
  renderFavorites();
}

function renderFavorites() {
  const container = favoritesContainer;
  container.innerHTML = "";
  favorites.forEach(news => {
    const div = document.createElement("div");
    div.className = "p-2 border rounded d-flex flex-column gap-1";
    div.innerHTML = `
      <span>${(news.title || "").slice(0, 60)}${(news.title || "").length > 60 ? "…" : ""}</span>
      <img src="${news.image || 'https://via.placeholder.com/400x200?text=No+Image'}"
           style="max-height:100px;object-fit:cover;width:100%;"
           onerror="this.src='https://via.placeholder.com/400x200?text=No+Image'">
      <span class="badge bg-${(news.sentiment || "neutral") === "positive" ? "success" : (news.sentiment === "negative" ? "danger" : "secondary")}">${news.sentiment || "neutral"}</span>
      <div class="d-flex gap-1 mt-1">
        <a href="${news.url}" target="_blank" class="btn btn-sm btn-primary flex-grow-1">📖 Read More</a>
        <button class="btn btn-sm btn-outline-info flex-grow-1 speak-btn">🔊 Listen</button>
        <button class="btn btn-sm btn-danger flex-grow-1">Remove</button>
      </div>
    `;
    div.querySelector(".speak-btn").addEventListener("click", () => speak(news.summary || news.description || news.title));
    div.querySelector(".btn-danger").addEventListener("click", () => {
      favorites = favorites.filter(f => f.url !== news.url);
      localStorage.setItem("favorites", JSON.stringify(favorites));
      renderFavorites();
    });
    container.appendChild(div);
  });
}

// Toggle Favorites
toggleFavoritesBtn.addEventListener("click", () => {
  if (favoritesContainer.style.display === "none" || favoritesContainer.style.display === "") {
    renderFavorites();
    favoritesContainer.style.display = "grid";
    window.scrollTo({ top: 0, behavior: "smooth" });
  } else {
    favoritesContainer.style.display = "none";
  }
});

// ---------------- Speech ----------------
let currentUtterance = null;
function speak(text) {
  if (!text) return;
  if (speechSynthesis.speaking) {
    speechSynthesis.cancel();
    if (currentUtterance && currentUtterance.text === text) {
      currentUtterance = null;
      return;
    }
  }
  currentUtterance = new SpeechSynthesisUtterance(text);
  currentUtterance.onend = () => { currentUtterance = null; };
  speechSynthesis.speak(currentUtterance);
}

// ---------------- Search History (buttons under box) ----------------
function addSearchHistory(query) {
  if (!query) return;
  let history = JSON.parse(localStorage.getItem("searchHistory")) || [];
  if (!history.includes(query)) history.push(query);
  localStorage.setItem("searchHistory", JSON.stringify(history));
  renderSearchHistory();
}

function renderSearchHistory() {
  const history = JSON.parse(localStorage.getItem("searchHistory")) || [];
  const container = document.getElementById("searchHistory");
  container.innerHTML = "";
  history.slice(-5).reverse().forEach(h => {
    const wrapper = document.createElement("span");
    wrapper.style.marginRight = "5px";
    const btn = document.createElement("button");
    btn.className = "btn btn-sm btn-outline-secondary";
    btn.textContent = h;
    btn.addEventListener("click", () => {
      document.getElementById("searchBox").value = h;
      hasMore = true;
      fetchNews(h, 1);
    });
    const del = document.createElement("button");
    del.className = "btn btn-sm btn-outline-danger ms-1";
    del.textContent = "×";
    del.addEventListener("click", () => {
      const newHistory = history.filter(item => item !== h);
      localStorage.setItem("searchHistory", JSON.stringify(newHistory));
      renderSearchHistory();
    });
    wrapper.appendChild(btn);
    wrapper.appendChild(del);
    container.appendChild(wrapper);
  });
}

// ---------------- Pagination ----------------
function updatePaginationButtons() {
  prevBtn.disabled = currentPage === 1;
  nextBtn.disabled = !hasMore;
}
prevBtn.addEventListener("click", () => { if (currentPage > 1) fetchNews(lastQuery, currentPage - 1); });
nextBtn.addEventListener("click", () => { if (hasMore) fetchNews(lastQuery, currentPage + 1); });

// ---------------- Search events ----------------
document.getElementById("searchBtn").addEventListener("click", () => {
  const query = document.getElementById("searchBox").value.trim();
  if (query) {
    hasMore = true;
    fetchNews(query, 1);
    addSearchHistory(query);
    hideSuggestions();
  }
});
document.querySelectorAll(".category-carousel button").forEach(btn => {
  btn.addEventListener("click", () => {
    const cat = btn.getAttribute("data-category") || btn.textContent.replace(/[^a-zA-Z ]/g, "").trim();
    document.getElementById("searchBox").value = cat;
    hasMore = true;
    fetchNews(cat, 1);
    addSearchHistory(cat);
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
});
document.getElementById("searchBox").addEventListener("keypress", function(e) {
  if (e.key === "Enter") {
    const query = this.value.trim();
    if (query) {
      hasMore = true;
      fetchNews(query, 1);
      addSearchHistory(query);
      hideSuggestions();
    }
  }
});

// ---------------- Initial ----------------
document.addEventListener("DOMContentLoaded", () => {
  renderFavorites();
  renderSearchHistory();
  fetchNews();
});

// ===================================================================
//          757655555555trrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrGOOGLE/YOUTUBE-LIKE AUTOCOMPLETE + HISTORY MERGE
// ===================================================================
const searchBox = document.getElementById("searchBox");
const suggestionsBox = document.getElementById("suggestionsBox");
let suggestionController = null;
let activeIndex = -1; // for keyboard nav

const staticSeed = [
  "Latest Technology News","AI Trends 2025","Bollywood Updates","Sports Live Scores",
  "Business Stock Market","Health & Fitness Tips","Science Discoveries",
  "Political Headlines","Travel Destinations","Food Recipes"
];

// small debounce for smooth typing
function debounce(fn, delay = 120) {
  let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
}

function hideSuggestions() {
  suggestionsBox.style.display = "none";
  suggestionsBox.innerHTML = "";
  activeIndex = -1;
}

// build one <li> item
function suggestionItem(text) {
  const li = document.createElement("li");
  li.className = "list-group-item list-group-item-action";
  li.textContent = text;
  li.style.cursor = "pointer";
  li.addEventListener("mousedown", (e) => { // mousedown so it fires before input blur
    e.preventDefault();
    selectSuggestion(text);
  });
  return li;
}

function selectSuggestion(text) {
  searchBox.value = text;
  hideSuggestions();
  hasMore = true;
  fetchNews(text, 1);
  addSearchHistory(text);
}

// merge arrays unique, keep order
function uniqMerge(...arrs) {
  const seen = new Set(); const out = [];
  arrs.flat().forEach(x => {
    const v = (x || "").toString().trim();
    if (v && !seen.has(v.toLowerCase())) { seen.add(v.toLowerCase()); out.push(v); }
  });
  return out;
}

async function getLiveSuggestions(query) {
  if (!query) { hideSuggestions(); return; }

  // cancel previous
  if (suggestionController) suggestionController.abort();
  suggestionController = new AbortController();

  // history suggestions (Google style: previously searched partials)
  const history = JSON.parse(localStorage.getItem("searchHistory")) || [];
  const historyFiltered = history
    .filter(h => h.toLowerCase().includes(query.toLowerCase()))
    .slice(-10).reverse();

  // category seeds like YouTube topic rows
  const categorySeeds = Array.from(document.querySelectorAll(".category-carousel .category-btn"))
    .map(b => b.getAttribute("data-category"));

  // external (Datamuse – fast/free)
  let apiWords = [];
  try {
    const res = await fetch(`https://api.datamuse.com/sug?s=${encodeURIComponent(query)}`, {
      signal: suggestionController.signal
    });
    const data = await res.json();
    apiWords = (data || []).map(d => d.word);
  } catch {}

  // final list → API first, then history, then static, then categories
  const full = uniqMerge(
    apiWords,
    historyFiltered,
    staticSeed.filter(x => x.toLowerCase().includes(query.toLowerCase())),
    categorySeeds.filter(x => x && x.toLowerCase().includes(query.toLowerCase()))
  ).slice(0, 12);

  if (!full.length) { hideSuggestions(); return; }

  // render
  suggestionsBox.innerHTML = "";
  full.forEach(text => suggestionsBox.appendChild(suggestionItem(text)));
  suggestionsBox.style.display = "block";
  activeIndex = -1;
}

// input → debounce live suggestions
const onType = debounce((e) => getLiveSuggestions(e.target.value.trim()), 120);
searchBox.addEventListener("input", onType);

// keyboard navigation like Google/YouTube
searchBox.addEventListener("keydown", (e) => {
  const items = Array.from(suggestionsBox.querySelectorAll(".list-group-item"));
  if (!items.length || suggestionsBox.style.display === "none") return;

  if (e.key === "ArrowDown") {
    e.preventDefault();
    activeIndex = (activeIndex + 1) % items.length;
  } else if (e.key === "ArrowUp") {
    e.preventDefault();
    activeIndex = (activeIndex - 1 + items.length) % items.length;
  } else if (e.key === "Enter") {
    if (activeIndex >= 0) {
      e.preventDefault();
      items[activeIndex].dispatchEvent(new Event("mousedown")); // select
      return;
    }
  } else {
    return; // other keys
  }

  items.forEach((el, i) => el.classList.toggle("active", i === activeIndex));
  if (activeIndex >= 0) {
    const val = items[activeIndex].textContent;
    // preview like Google
    searchBox.setAttribute("aria-activedescendant", val);
  }
});

// hide on outside click / blur
document.addEventListener("click", (e) => {
  if (!suggestionsBox.contains(e.target) && e.target !== searchBox) hideSuggestions();
});
searchBox.addEventListener("blur", () => setTimeout(hideSuggestions, 100)); // slight delay so click works
// ---------------- One-Click Share ----------------
document.addEventListener("click", function (e) {
  if (e.target && e.target.classList.contains("share-btn")) {
    const url = e.target.getAttribute("data-url");
    if (navigator.share) {
      navigator.share({
        title: "Check out this news!",
        text: "I found an interesting news article for you.",
        url: url
      }).then(() => {
        console.log("News shared successfully!");
      }).catch((error) => {
        console.log("Sharing failed:", error);
      });
    } else {
      // Fallback for browsers without native share
      const encodedUrl = encodeURIComponent(url);
      const shareOptions = `
        <div style="padding:10px;font-size:16px;">
          <a href="https://wa.me/?text=${encodedUrl}" target="_blank">📱 WhatsApp</a> |
          <a href="https://twitter.com/intent/tweet?url=${encodedUrl}" target="_blank">🐦 Twitter</a> |
          <a href="https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}" target="_blank">📘 Facebook</a> |
          <a href="mailto:?subject=Check%20out%20this%20news!&body=${encodedUrl}" target="_blank">📧 Email</a> |
        </div>
      `;
      const w = window.open("", "_blank", "width=400,height=300");
      w.document.write(shareOptions);
    }
  }
});





