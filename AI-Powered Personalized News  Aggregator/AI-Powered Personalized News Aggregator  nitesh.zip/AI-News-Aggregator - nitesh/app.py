import os
import time
import logging
import json
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from dotenv import load_dotenv
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# ------------------- ENV + Logging Setup -------------------
load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

app = Flask(__name__, template_folder="templates", static_folder="static")
CORS(app)

# ------------------- LLaMA Model Init -------------------
LLAMA_PATH = os.getenv("LLAMA_MODEL_PATH", "")
LLM = None

try:
    from llama_cpp import Llama
    if not LLAMA_PATH:
        logging.error("⚠️ Environment variable LLAMA_MODEL_PATH is missing! Set the path to your GGUF model.")
    else:
        logging.info("🔄 Loading LLaMA 2 model... Please wait...")
        LLM = Llama(
            model_path=LLAMA_PATH,
            n_ctx=int(os.getenv("LLAMA_N_CTX", "2048")),
            n_threads=int(os.getenv("LLAMA_N_THREADS", "6"))
        )
        logging.info("✅ LLaMA 2 Model Loaded Successfully!")
except ImportError:
    logging.error("❌ llama-cpp not installed! Run: pip install llama-cpp-python")
except Exception as e:
    logging.exception("❌ LLaMA initialization failed")

# ------------------- Sentiment Analyzer -------------------
SENT = SentimentIntensityAnalyzer()

def _now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def _sentiment_label(text):
    s = SENT.polarity_scores(text).get("compound", 0)
    return "positive" if s > 0.05 else "negative" if s < -0.05 else "neutral"

# ------------------- LLaMA News Generator -------------------
def generate_news(topic, language="en", limit=3):  # <-- Limit 3 for safety
    """
    Generates AI-generated news headlines using LLaMA 2.
    """
    if LLM is None:
        logging.warning("⚠️ LLaMA model not loaded! Returning empty list.")
        return []

    lang_note = "Write responses in Hindi." if language.startswith("hi") else "Write responses in English."
    prompt = (
        f"You are an AI-powered journalist.\n"
        f"{lang_note}\n"
        f"Generate {limit} latest breaking news headlines about '{topic}'.\n"
        f"Return ONLY a valid JSON array with {limit} objects.\n"
        f"Each object must have: title, summary.\n"
        f"No extra text, no explanations."
    )

    try:
        response = LLM.create_chat_completion(
            messages=[
                {"role": "system", "content": "You are an AI news generator."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1024,
            temperature=0.7,
            top_p=0.9
        )

        text = response["choices"][0]["message"]["content"].strip()

        # Safely parse JSON
        try:
            parsed = json.loads(text)
        except Exception:
            s, e = text.find("["), text.rfind("]")
            parsed = json.loads(text[s:e+1]) if s != -1 and e != -1 and e > s else []

        return parsed[:limit] if isinstance(parsed, list) else []
    except Exception as e:
        logging.error("❌ LLaMA News Generation Error: %s", e)
        return []

# ------------------- API Endpoint -------------------
@app.route("/get_news", methods=["GET"])
def get_news():
    topic = request.args.get("query", "technology")
    lang = request.args.get("language", "en")
    limit = int(request.args.get("page_size", "3"))  # Default 3

    logging.info(f"🔍 Generating AI News → Topic: {topic}, Lang: {lang}, Limit: {limit}")
    generated = generate_news(topic, lang, limit=limit)

    items = []
    for i, news in enumerate(generated):
        title = news.get("title", f"News {i+1}")
        summary = news.get("summary", title)
        sentiment = _sentiment_label(summary)
        items.append({
            "title": title,
            "summary": summary,
            "description": summary,
            "url": "#",
            "publishedAt": _now_iso(),
            "source": "LLaMA2",
            "image": "https://via.placeholder.com/400x200?text=AI+News",
            "sentiment": sentiment,
            "category": topic
        })

    return jsonify({
        "error": False,
        "items": items,
        "source": "LLaMA2",
        "page": 1,
        "page_size": len(items),
        "has_more": False
    })

# ------------------- Default Routes -------------------
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/health")
def health():
    return jsonify({"ok": True, "llama_loaded": LLM is not None})

# ------------------- Run Flask Server -------------------
if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    logging.info(f"🚀 Starting Flask server on http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=True, use_reloader=False)
